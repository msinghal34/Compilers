void main()
{

int a;
float b;
a=-2;

if(!(a==0)){
  b=7.8;
}

}
