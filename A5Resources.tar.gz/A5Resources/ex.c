void main()
{
  int a,b,c;

  c=20;
  a=30;
 if(c>20)
  a=20;
 else
  b=a+30;
}
